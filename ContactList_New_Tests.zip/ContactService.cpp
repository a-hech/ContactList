#include "Contact.cpp"

#include <iostream>
#include <vector>
#include <string>

class ContactService {
private:
    // create a vector to store contact data
    vector<Contact> contacts;

public:
    // to add new contacts
    bool addContact(const Contact& contact) {
        contacts.push_back(contact);
        return true;
    }

    // to delete existing contact
    bool deleteContact(const string& ID) {
        // access vector
        for (auto it = contacts.begin(); it != contacts.end(); ++it) {
            // if contact ID is found
            if (it->getContactID() == ID) {
                // to remove the contact from the vector
                contacts.erase(it);
                return true;
            }
        }

        // else boolean is returned as false
        return false;
    }

    // to update existing contacts 
    bool updateContact(const string& contactID, const string& firstName, const string& lastName, const string& phoneNumber, const string& address) {
        // access vector
        for (Contact& contactList : contacts) {
            // to check if the contact ID exists 
            if (contactList.getContactID() == contactID) {
                // to ensure the first name isn't the same and the length is 10 characters or less
                if (!firstName.empty() && (firstName.length() <= 10)) {
                    // to update the first name 
                    contactList.setFirstName(firstName);
                }
                // to ensure the last name isn't the same and the length is 10 characters or less
               if (!lastName.empty() && (lastName.length() <= 10)) {
                    // to update the last name
                    contactList.setLastName(lastName);
                }
                // to ensure the phone number isn't the same and length is exactly 10 characters
                if (!phoneNumber.empty() && (phoneNumber.length() == 10)) {
                    // to update the phone number
                    contactList.setPhoneNumber(phoneNumber);
                }
                // to ensure the address isn't the same and the length is 30 characters or less
                if (!address.empty() && (address.length() <= 30)) {
                    // to update the address
                    contactList.setAddress(address);
                }
                return true;
            }
        }
        return false;
    }
};