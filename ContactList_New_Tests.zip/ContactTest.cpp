#include <stdexcept>

#include "gtest/gtest.h"
#include "Contact.cpp"

// test the contact class when the data is less than the boundary 
TEST(ContactTest, contactShort) {
	Contact contact = Contact("123", "Jane", "Doe", "1234567890", "123 Cherry Ln");
	ASSERT_EQ(contact.getContactID(), "123");
	ASSERT_EQ(contact.getFirstName(), "Jane");
	ASSERT_EQ(contact.getLastName(), "Doe");
	ASSERT_EQ(contact.getPhoneNumber(), "1234567890");
	ASSERT_EQ(contact.getAddress(), "123 Cherry Ln");
}

// test the contact class when the data is exactly at the boundary
TEST(ContactTest, contactExact) {
	Contact contact("123ABC456D", "***Jane***", "****Doe***", "1234567890", "123 Cherry Ln Jupiter FL 12345");
	ASSERT_EQ(contact.getContactID(), "123ABC456D");
	ASSERT_EQ(contact.getFirstName(), "***Jane***");
	ASSERT_EQ(contact.getLastName(), "****Doe***");
	ASSERT_EQ(contact.getPhoneNumber(), "1234567890");
	ASSERT_EQ(contact.getAddress(), "123 Cherry Ln Jupiter FL 12345");
}

// test the contact class when the ID is too long
TEST(ContactTest, IDLong) {
	Contact contact("123ABC456123", "***Jane***", "****Doe***", "1234567890", "123 Cherry Ln Jupiter FL 12345");
	try {
		contact.getContactID();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid contact ID");
	}
}

// test the contact class when the ID is empty
TEST(ContactTest, IDEmpty) {
	Contact contact("", "***Jane***", "****Doe***", "1234567890", "123 Cherry Ln Jupiter FL 12345");
	try {
		contact.getContactID();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid contact ID");
	}
}

// test the contact class when the name is too long
TEST(ContactTest, firstNameLong) {
	Contact contact("123", "JaneJaneJane", "****Doe***", "1234567890", "123 Cherry Ln Jupiter FL 12345");
	try {
		contact.getFirstName();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid name");
	}
}

// test the contact class when the name is empty
TEST(ContactTest, firstNameEmpty) {
	Contact contact("123", "", "****Doe***", "1234567890", "123 Cherry Ln Jupiter FL 12345");
	try {
		contact.getFirstName();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid name");
	}
}

// test the contact class when the last name is too long
TEST(ContactTest, lastNameLong) {
	Contact contact("123", "Jane", "DoeDoeDoeDoe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
	try {
		contact.getLastName();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid last name");
	}
}

// test the contact class when the name is empty
TEST(ContactTest, lastNameEmpty) {
	Contact contact("123", "Jane", "", "1234567890", "123 Cherry Ln Jupiter FL 12345");
	try {
		contact.getLastName();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid last name");
	}
}

// test the contact class when the phone number is too long
TEST(ContactTest, phoneNumberLong) {
	Contact contact("123", "Jane", "****Doe***", "1234567890123", "123 Cherry Ln Jupiter FL 12345");
	try {
		contact.getPhoneNumber();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid phone number");
	}
}

// test the contact class when the phone number is empty
TEST(ContactTest, phoneNumberEmpty) {
	Contact contact("123", "Jane", "****Doe***", "", "123 Cherry Ln Jupiter FL 12345");
	try {
		contact.getPhoneNumber();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid phone number");
	}
}

// test the contact class when the address is too long
TEST(ContactTest, addressLong) {
	Contact contact("123", "Jane", "****Doe***", "1234567890", "123 Cherry Ln Jupiter FL 12345 12345");
	try {
		contact.getAddress();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid address");
	}
}

// test the contact class when the address is empty
TEST(ContactTest, addressEmpty) {
	Contact contact("123", "Jane", "****Doe***", "1234567890", "");
	try {
		contact.getAddress();
	}
	catch (const invalid_argument& ex) {
		// expect specific message
		EXPECT_EQ(ex.what(), "Invalid address");
	}
}