#include "gtest/gtest.h"
#include "ContactService.cpp"
//#include "Contact.cpp"

// test the add contact method 
TEST(ContactServiceTest, addContact) {
	Contact contact = Contact("123", "Jane", "Doe", "1234567890", "123 Cherry Ln");
	ContactService service = ContactService();
	ASSERT_TRUE(service.addContact(contact));
}

// test the delete contact method
TEST(ContactServiceTest, deleteContact) {
	Contact contact = Contact("123", "Jane", "Doe", "1234567890", "123 Cherry Ln");
	ContactService service = ContactService();
	ASSERT_TRUE(service.addContact(contact));
	ASSERT_TRUE(service.deleteContact("123"));
}

// test the update contact method
// test first name update
TEST(ContactServiceTest, updateFirstName) {
	Contact contact = Contact("123", "Jane", "Doe", "1234567890", "123 Cherry Ln");
	ContactService service = ContactService();
	ASSERT_TRUE(service.addContact(contact));
	ASSERT_TRUE(service.updateContact("123", "Helen", "Doe", "1234567890", "123 Cherry Ln"));
}

// test last name update
TEST(ContactServiceTest, updateLastName) {
	Contact contact = Contact("123", "Jane", "Doe", "1234567890", "123 Cherry Ln");
	ContactService service = ContactService();
	ASSERT_TRUE(service.addContact(contact));
	ASSERT_TRUE(service.updateContact("123", "Jane", "White", "1234567890", "123 Cherry Ln"));
}

// test phone number update
TEST(ContactServiceTest, updateNumber) {
	Contact contact = Contact("123", "Jane", "Doe", "1234567890", "123 Cherry Ln");
	ContactService service = ContactService();
	ASSERT_TRUE(service.addContact(contact));
	ASSERT_TRUE(service.updateContact("123", "Jane", "Doe", "1111111111", "123 Cherry Ln"));
}

// test address update
TEST(ContactServiceTest, updateAddress) {
	Contact contact = Contact("123", "Jane", "Doe", "1234567890", "123 Cherry Ln");
	ContactService service = ContactService();
	ASSERT_TRUE(service.addContact(contact));
	ASSERT_TRUE(service.updateContact("123", "Jane", "Doe", "1234567890", "456 Berry Ln"));
}