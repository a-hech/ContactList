#include <iostream>
#include <stdexcept>
#include <string>

using namespace std;

class Contact {
private:
    string contactID;
    string firstName;
    string lastName;
    string phoneNumber;
    string address;

public:
    // constructor to set contact parameters
    Contact(const string& contactID, const string& firstName, const string& lastName,
        const string& phoneNumber, const string& address) {

        // Ensure the contact ID can't be null or greater than 10 characters
        if (contactID.empty() || contactID.length() > 10) {
            throw invalid_argument("Invalid contact ID");
        }
        // Ensure the first name can't be null or greater than 10 characters
        if (firstName.empty() || firstName.length() > 10) {
            throw invalid_argument("Invalid name");
        }
        // Ensure the last name can't be null or greater than 10 characters 
        if (lastName.empty() || lastName.length() > 10) {
            throw invalid_argument("Invalid last name");
        }
        // Ensure the phone number can't be null and has to be 10 characters
        if (phoneNumber.empty() || phoneNumber.length() != 10) {
            throw invalid_argument("Invalid phone number");
        }
        // Ensure the address can't be null or greater than 30 characters
        if (address.empty() || address.length() > 30) {
            throw invalid_argument("Invalid address");
        }

        this->contactID = contactID;
        this->firstName = firstName;
        this->lastName = lastName;
        this->phoneNumber = phoneNumber;
        this->address = address;

    }

    // Setters and getters
    string getContactID() const {
        return contactID;
    }

    void setContactID(string contactID) {
        this->contactID = contactID;
    }

    void setFirstName(string firstName) {
        this->firstName = firstName;
    }

    string getFirstName() const {
        return firstName;
    }

    void setLastName(string lastName) {
        this->lastName = lastName;
    }

    string getLastName() const {
        return lastName;
    }

    void setPhoneNumber(string phoneNumber) {
        this->phoneNumber = phoneNumber;
    }

    string getPhoneNumber() const {
        return phoneNumber;
    }

    void setAddress(string address) {
        this->address = address;
    }

    string getAddress() const {
        return address;
    }
};
