#include <iostream>
#include <string>

using namespace std;

// create contact structure
struct Contact {
	string contactID;
	string firstName;
	string lastName;
	string phoneNumber;
	string address;
};
