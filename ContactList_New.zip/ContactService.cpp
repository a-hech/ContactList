// implement contact file
#include "Contact.cpp"

#include <iostream>
#include <vector>
#include <string>

using namespace std;

// create contact vector
vector<Contact> contacts;

// method to add a contact
void addContact() {
	// create new contact in vector
	Contact newContact;

	// outputs and inputs for user menu 
	// use newContact.[] to add user input to correct attribute in the contact vector
	
	// add contact
	cout << "Enter Contact ID: \n";
	getline(cin, newContact.contactID);

	// input validation 
	while (newContact.contactID.length() > 10 || newContact.contactID.empty()) {
		cout << "\nPlease enter an ID with less than 10 characters\n";
		getline(cin, newContact.contactID);
	}

	// add first name
	cout << "\nEnter first name: \n";
	getline(cin, newContact.firstName);

	// input validation
	while (newContact.firstName.length() > 10 || newContact.firstName.empty()) {
		cout << "\nPlease enter a name with less than 10 characters\n";
		getline(cin, newContact.firstName);
	}

	cout << "\nEnter last name: \n";
	getline(cin, newContact.lastName);

	// input validation 
	while (newContact.lastName.length() > 10 || newContact.lastName.empty()) {
		cout << "\nPlease enter a name with less than 10 characters\n";
		getline(cin, newContact.lastName);
	}

	// add number
	cout << "\nEnter phone number (no dashes): \n";
	getline(cin, newContact.phoneNumber);

	// input validation 
	while (newContact.phoneNumber.length() != 10 || newContact.phoneNumber.empty()) {
		cout << "\nPlease enter a valid phone number\n";
		getline(cin, newContact.phoneNumber);
	}

	// add address
	cout << "\nEnter address: \n";
	getline(cin, newContact.address);

	// input validation 
	while (newContact.address.length() > 10 || newContact.address.empty()) {
		cout << "\nPlease enter an address with less than 30 characters\n";
		getline(cin, newContact.address);
	}

	// add new information to vector
	contacts.push_back(newContact);
	// inform user 
	cout << "\nContact added\n";
}

// method to update a contact
void updateContact() {
	// contact variables
	string firstName;
	string lastName;
	string phoneNumber;
	string address;
	
	// if there are no contacts
	if (contacts.empty()) {
		cout << "\nNo contacts to update\n";
		return;
	}

	// prompt user
	cout << "\nEnter the Contact ID for the contact you wish to update: \n";
	string ID;
	cin >> ID;

	// access vector
	auto it = contacts.begin();
	for (; it != contacts.end(); ++it) {
		// if ID exists
		if (it->contactID == ID) {
			// get user input and set it equal to the right contact attribute
			
			// first name update
			cout << "\nEnter the first name: \n";
			cin >> firstName;
			
			// input validation
			while (firstName.length() > 10 || firstName.empty()) {
				cout << "\nPlease enter a name with less than 10 characters\n";
				cin >> firstName;
			}

			(*it).firstName;
			
			// last name update
			cout << "\nEnter the last name: \n";
			cin >> lastName;
			
			// input validation
			while (lastName.length() > 10 || lastName.empty()) {
				cout << "\nPlease enter a name with less than 10 characters\n";
				cin >> lastName;
			}

			(*it).lastName;

			// number update 
			cout << "\nEnter the phone number: \n";
			cin >> phoneNumber;
			
			// input validation
			while (phoneNumber.length() != 10 || phoneNumber.empty()) {
				cout << "\nPlease enter a valid phone number\n";
				cin >> phoneNumber;
			}

			(*it).phoneNumber;
			
			// address update
			cout << "\nEnter the address: \n";
			cin >> address;
			// input validation
			while (address.length() > 10 || address.empty()) {
				cout << "\nPlease enter an address with less than 30 characters\n";
				cin >> address;
			}

			(*it).address;

			// inform user
			cout << "\nContact updated\n";
		}
	}
}

// method to delete a contact
void deleteContact() {
	// if there are no contacts
	if (contacts.empty()) {
		cout << "\nYou don't have any contacts\n";
		return;
	}

	// prompt user
	cout << "\nEnter the Contact ID for the contact you wish to delete: \n";
	string ID;
	getline(cin, ID);

	// access vector 
	auto it = contacts.begin();
	for (; it != contacts.end(); ++it) {
		// if ID is found
		if (it->contactID == ID) {
			// delete contact
			it = contacts.erase(it);
			// inform user
			cout << "\nContact deleted\n";
			break;
		}
	}

	if (it == contacts.end()) {
		cout << "\nNo contact found\n";
	}
}

// method to show contacts
void showContacts() {
	// if there are no contacts
	if (contacts.empty()) {
		cout << "\nYou don't have any contacts\n";
		return;
	}

	// if there are contacts
	else {
		cout << "\nYour Contacts: \n";
		// read vector 
		for (const auto& contact : contacts) {
			cout << "\nContact ID: " << contact.contactID;
			cout << "\nName: " << contact.firstName << " " << contact.lastName;
			cout << "\nPhone Number: " << contact.phoneNumber;
			cout << "\nAddress: " << contact.address << "\n";
		}
	}
}

// main function with user menu
int main() {
	int input;

	do {
		cout << "\nContact List Menu\n";
		cout << "\n1. Add Contact";
		cout << "\n2. Show Contacts";
		cout << "\n3. Update Contact";
		cout << "\n4. Delete Contact";
		cout << "\n0. Exit Program";
		// prompt user
		cout << "\nWhat would you like to do?\n";
		cin >> input;
		cin.ignore();

		switch (input) {
		case 1: 
			addContact();
			break;
		case 2:
			showContacts();
			break;
		case 3:
			updateContact();
			break;
		case 4:
			deleteContact();
			break;
		case 0: 
			cout << "Exiting Program\n";
			break;
		default:
			cout << "Please enter a valid choice";
		}
	}

	while (input != 0);

	return 0;

}