
import java.util.ArrayList;

public class ContactService {
	
	// creates an array to store contact data
	private ArrayList<Contact> contacts = new ArrayList<>();

	// to add new contacts
	public boolean addContact(Contact contact) {
		boolean existingContact = false;
		// access array
		for (Contact contactList : contacts) {
			// if contact already exists, nothing is done and boolean is true
			if (contactList.equals(contact)) {
				existingContact = true;
			}
		}
		
		// if contact doesn't exist 
		if (!existingContact) {
			// new contact is added to array
			contacts.add(contact);
			// boolean is true
			existingContact = true;
		}
		
		// else boolean is false
		else {
			return false;
		}
		
		return existingContact;
	}
	
	// to delete existing contact
	public boolean deleteContact(String ID) {
		// access array
		for (Contact contact : contacts) {
			// if contact ID is found
			if (contact.getContactID().equals(ID)) {
				// to remove the contact from the array
				contacts.remove(contact);
				return true;
			}
		}
		
		// else boolean is returned as false
		return false;
	}
	
	// to update existing contacts 
	public boolean updateContact(String contactID, String firstName, String lastName, String phoneNumber, String address) {
		// access array
		for (Contact contactList : contacts) {
			// to check if the contact ID exists 
			if (contactList.getContactID().equals(contactID)) {
				// to ensure the first name isn't the same and the length is 10 characters or less
				if (!firstName.equals("") && (firstName.length() <= 10)) {
					// to update the first name 
					contactList.setFirstName(firstName);
				}
				// to ensure the last name isn't the same and the length is 10 characters or less
				if (!lastName.equals("") && (lastName.length() <= 10)) {
					// to update the last name
					contactList.setLastName(lastName);
				}
				// to ensure the phone number isn't the same and length is exactly 10 characters
				if (!phoneNumber.equals("") && (phoneNumber.length() == 10)) {
					// to update the phone number
					contactList.setPhoneNumber(phoneNumber);
				}
				// to ensure the address isn't the same and the length is 30 characters or less
				if (!address.equals("") && (address.length() <= 30)) {
					// to update the address
					contactList.setAddress(address);
				}
				
				return true;
			}
		}
		
		return false;
	}
}
