
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


public class ContactServiceTest {
	
	// to test the add contact boolean
	@Test 
	void testAddContact() {
		Contact contact = new Contact("123ABC456D", "Jane", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		ContactService service = new ContactService();
		// asserts that the test contact has been added and isn't null
		assertTrue(service.addContact(contact));
		assertNotNull(contact);
	}
	
	// to test the delete contact boolean 
	@Test 
	void testDeleteContact() {
		Contact contact = new Contact("123ABC456D", "Jane", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		ContactService service = new ContactService();
		// asserts that the test contact has been added and isn't null
		assertTrue(service.addContact(contact));
		assertNotNull(contact);
		// asserts that the test contact has been deleted
		assertTrue(service.deleteContact("123ABC456D"));
	}

	// to test the update contact boolean can update the first name
	@Test
	void testUpdateFirstName() {
		Contact contact = new Contact("123ABC456D", "Jane", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		ContactService service = new ContactService();
		// asserts that the test contact has been added and isn't null
		assertTrue(service.addContact(contact));
		assertNotNull(contact);
		// asserts that the test contact first name has been updated
		assertTrue(service.updateContact("123ABC456D", "Helen", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345"));
		assertEquals(contact.getFirstName(), "Helen");
	}
	
	// to test that the update contact boolean can update the last name
	@Test
	void testUpdateLastName() {
		Contact contact = new Contact("123ABC456D", "Jane", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		ContactService service = new ContactService();
		// asserts that the test contact has been added and isn't null
		assertTrue(service.addContact(contact));
		assertNotNull(contact);
		// asserts that the test contact last name has been updated
		assertTrue(service.updateContact("123ABC456D", "Jane", "Wilde", "1234567890", "123 Cherry Ln Jupiter FL 12345"));
		assertEquals(contact.getLastName(), "Wilde");
	}
	
	// to test that the update contact boolean can update the phone number
	@Test
	void testUpdatePhoneNumber() {
		Contact contact = new Contact("123ABC456D", "Jane", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		ContactService service = new ContactService();
		// asserts that the test contact has been added and isn't null
		assertTrue(service.addContact(contact));
		assertNotNull(contact);
		// asserts that the test contact phone number has been updated
		assertTrue(service.updateContact("123ABC456D", "Jane", "Doe", "4436524589", "123 Cherry Ln Jupiter FL 12345"));
		assertEquals(contact.getPhoneNumber(), "4436524589");
	}
	
	// to test that the update contact boolean can update the address
	@Test
	void testUpdateAddress() {
		Contact contact = new Contact("123ABC456D", "Jane", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		ContactService service = new ContactService();
		// asserts that the test contact has been added and is't null
		assertTrue(service.addContact(contact));
		assertNotNull(contact);
		// asserts that the test contact address has been updated
		assertTrue(service.updateContact("123ABC456D", "Jane", "Doe", "1234567890", "001 Berry Ln Jupiter FL 12345"));
		assertEquals(contact.getAddress(), "001 Berry Ln Jupiter FL 12345");
	}
}
