import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class ContactTest {
	
	// tests the contact class when the data is <boundary
	@Test 
	void testContactShort() {
		Contact contact = new Contact("123", "Jane", "Doe", "1234567890", "1 Rock Ln Tampa FL 12345");
		assertTrue(contact.getContactID().equals("123"));
		assertTrue(contact.getFirstName().equals("Jane"));
		assertTrue(contact.getLastName().equals("Doe"));
		assertTrue(contact.getPhoneNumber().equals("1234567890"));
		assertTrue(contact.getAddress().equals("1 Rock Ln Tampa FL 12345"));
	}
	
	// tests the contact class when the data is ==boundary
	void testContactExact() {
		Contact contact = new Contact("123ABC456D", "***Jane***", "****Doe***", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		assertTrue(contact.getContactID().equals("123ABC456D"));
		assertTrue(contact.getFirstName().equals("****Jane****"));
		assertTrue(contact.getLastName().equals("****Doe***"));
		assertTrue(contact.getPhoneNumber().equals("1234567890"));
		assertTrue(contact.getAddress().equals("123 Cherry Ln Jupiter FL 12345"));
	}
	
	// tests that an exception is thrown when the contact ID is too long 
	@Test 
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123456789123", "Jane", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		});
	}
	
	// tests that an exception is thrown when the contact ID is null
	@Test 
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Jane", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		});
	}
	
	// tests that an exception is thrown when the first name is too long 
	@Test 
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123ABC456D", "Christopher", "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		});
	}
	
	// tests that an exception is thrown when the first name is null
	@Test 
	void testFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123ABC456D", null, "Doe", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		});
	}
	
	// tests that an exception is thrown when the last name is too long 
	@Test 
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123AC456D", "Jane", "Fitzgeralds", "1234567890", "123 Cherry Ln Jupiter FL 12345");
		});
	}
	
	// tests that an exception is thrown when the last name is null
	@Test 
	void testLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123ABC456D", "Jane", null, "1234567890", "123 Cherry Ln Jupiter FL 12345");
		});
	}
	
	// tests that an exception is thrown when the phone number is too short 
	@Test 
	void testPhoneNumberTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123AC456D", "Jane", "Doe", "000", "123 Cherry Ln Jupiter FL 12345");
		});
	}
	// tests that an exception is thrown when the phone number is too long 
	@Test 
	void testPhoneNumberTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123AC456D", "Jane", "Doe", "1234567890123", "123 Cherry Ln Jupiter FL 12345");
		});
	}
	
	// tests that an exception is thrown when the phone number is null
	@Test 
	void testPhoneNumberNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123ABC456D", "Jane", "Doe", null, "123 Cherry Ln Jupiter FL 12345");
		});
	}
	
	// tests that an exception is thrown when the address is too long 
	@Test 
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123AC456D", "Jane", "Doe", "1234567890", "1005 Cherry Lane Jupiter Florida 12345");
		});
	}
	
	// tests that an exception is thrown when the address is null
	@Test 
	void testAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123ABC456D", "Jane", "Doe", "1234567890", null);
		});
	}
}
